import paramiko
import time
import tv5

class ssh_connection_to_Raspberry_Pi():
    def __init__(self,username,password,pi_hostname,port):
        self.username = username
        self.password = password
        self.kali_hostname = pi_hostname
        self.port = port

    def connection(self):
            try:
                self.client = paramiko.SSHClient()
                self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                self.client.connect(self.kali_hostname, self.port, self.username, self.password, timeout=10)
                self.sftp = self.client.open_sftp()
            except Exception:
                print('Connection Exception!!')
                raise

    def get_file(self):
        self.sftp.get("/home/cat_packet/-01.cap", "AP.cap")
        
    def put_file(self):
        self.sftp.put("result_HandShape_Packet.txt", "/home/cat_packet/result_HandShape_Packet.txt")

class ssh_connection_to_Kali_Linux():
    def __init__(self,username,password,pi_hostname,port):
        self.username = username
        self.password = password
        self.kali_hostname = pi_hostname
        self.port = port

    def connection(self):
            try:
                self.client = paramiko.SSHClient()
                self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                self.client.connect(self.kali_hostname, self.port, self.username, self.password, timeout=10)
                self.sftp = self.client.open_sftp()
            except Exception:
                print('Connection Exception!!')
                raise
    
    def get_file(self):
        self.sftp.get("/root/Desktop/result_HandShape_Packet.txt", "result_HandShape_Packet.txt")
    def put_file(self):
        self.sftp.put("AP.cap", "/root/Desktop/AP.cap")

if __name__ == '__main__':
    connection_to_Raspberry_Pi = ssh_connection_to_Raspberry_Pi("pi","raspberry","192.168.43.72","22")
    connection_to_Raspberry_Pi.connection()
    connection_to_Raspberry_Pi.get_file()
    print("Successfully get the packet")
    print("Sending HandShape packet to Kali Linux......")
    connection_to_Kali_Linux = ssh_connection_to_Kali_Linux("root","toor","192.168.174.128","22")
    connection_to_Kali_Linux.connection()
    connection_to_Kali_Linux.put_file()
    print("Successfully put the packet")
    tv5.run()
    connection_to_Kali_Linux.get_file()
    print("Successfully get the packet")
    print("Sending result to Raspberry Pi......")
    connection_to_Raspberry_Pi.put_file()
    print("Successfully put the packet")