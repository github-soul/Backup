Difference between the Kali version Routersploit and RPi version Routersploit:
1. No "return headers, *self.credentials" statement in all files in .\routersploit\modules\creds\generic !!!
2. Extra try...except...finally statments in the if-else clause--"if self.default_wordlists_required(RoutersploitInterpreter._show_advanced(self, f"{self.file_reading_1()[v][3]}"))==True:"!!!