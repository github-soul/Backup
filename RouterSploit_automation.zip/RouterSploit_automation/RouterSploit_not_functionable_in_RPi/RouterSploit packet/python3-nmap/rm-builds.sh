rm -rf build
rm -rf dist
rm -rf python3_nmap.egg-info
