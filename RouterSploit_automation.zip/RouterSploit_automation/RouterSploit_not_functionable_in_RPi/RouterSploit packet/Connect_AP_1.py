import os

class Auto_Connect_AP():
    def __init__(self, ssid, password, network_interface):
        self.ssid = f"\"{ssid}\""  # Input ssid here
        self.psk = f"\"{password}\""  # Input password here
        self.network_interface = str(network_interface)

    def Store_Data(self):
        file = open("/etc/wpa_supplicant/wpa_supplicant.conf", mode="w", encoding="utf-8")
        file.write(
            "ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev\nupdate_config=1\ncountry=HK\nnetwork={{\nssid={}\npsk={}\n}}\n".format(self.ssid, self.psk))
        file.close()

    def ConnectAP(self):
        # save the configuration
        os.system(f'wpa_cli -i {self.network_interface} reconfigure')  
        # connect to the AP without reboot
        os.system(f'wpa_cli -i {self.network_interface} reconnect')
        os.system('dhcpcd')

    def Stop_Connect(self):
        file = open("/etc/wpa_supplicant/wpa_supplicant.conf", mode="w", encoding="utf-8")
        file.write(
            "ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev\nupdate_config=1\ncountry=HK")
        file.close()
        os.system(f'wpa_cli -i {self.network_interface} reconfigure')
        os.system(f'wpa_cli -i {self.network_interface} reconnect')

if __name__ == "__main__":
    #Only need to revise the following data
    #type chmod 777 /etc/wpa_supplicant/wpa_supplicant.conf before run this program
    #type chmod 777 /etc/wpa_supplicant/wpa_supplicant.conf before run this program
    #type chmod 777 /etc/wpa_supplicant/wpa_supplicant.conf before run this program
    Test_Connect_AP = Auto_Connect_AP("DESKTOP-NRT4GTL 6847","903}20Hc","wlan1")
    Test_Connect_AP.Store_Data()
    print("Input AP SSID and Password successfully")
    Test_Connect_AP.ConnectAP()

    #stop connect
    #Auto_Connect_AP.Stop_Connect()