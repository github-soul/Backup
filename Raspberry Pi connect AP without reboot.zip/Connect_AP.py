import os

class Auto_Connect_AP():
    @staticmethod
    def Stop_Connect():
        file = open("/etc/wpa_supplicant/wpa_supplicant.conf", mode="w", encoding="utf-8")
        file.write(
            "ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev\nupdate_config=1\ncountry=HK")
        file.close()
        os.system('wpa_cli -i wlan0 reconfigure')
        os.system('wpa_cli -i wlan0 reconnect')

    def __init__(self, ssid, password):
        self.ssid = f"\"{ssid}\""  # Input ssid here
        self.psk = f"\"{password}\""  # Input password here

    def Store_Data(self):
        file = open("/etc/wpa_supplicant/wpa_supplicant.conf", mode="w", encoding="utf-8")
        file.write(
            "ctrl_interface=DIR=/var/run/wpa_supplicant GROUP=netdev\nupdate_config=1\ncountry=HK\nnetwork={{\nssid={}\npsk={}\n}}\n".format(self.ssid, self.psk))
        file.close()

    def ConnectAP(self):
        # save the configuration
        os.system('wpa_cli -i wlan0 reconfigure')  
        # connect to the AP without reboot
        os.system('wpa_cli -i wlan0 reconnect')

if __name__ == "__main__":
    #Only need to revise the following data
    #type chmod 777 /etc/wpa_supplicant/wpa_supplicant.conf before run this program
    #type chmod 777 /etc/wpa_supplicant/wpa_supplicant.conf before run this program
    #type chmod 777 /etc/wpa_supplicant/wpa_supplicant.conf before run this program
    Test_Connect_AP = Auto_Connect_AP("Mi","12345678")
    Test_Connect_AP.Store_Data()
    print("Input AP SSID and Password successfully")
    Test_Connect_AP.ConnectAP()

    #stop connect
    #Auto_Connect_AP.Stop_Connect()