import subprocess
from tkinter import *
from tkinter.ttk import Progressbar
import threading

mainwindow = Tk()
mainwindow.title("Subprocess + Demo")

def startcommand():
    t = threading.Thread(target=runcommand)
    t.start()

def runcommand():
    disable_text()
    cmd = cmdtextbox.get()
    print(cmd)
    outputlabel['text'] = "OUTPUT: command executing - please wait..."
    outputlabel['fg'] = "red"
    pbar.grid()
    pbar.start()
    cmd_result = subprocess.run(cmd,shell=True,capture_output=True,text=True)
    outputlabel['text'] = "output: "
    outputlabel['fg'] = "green"
    pbar.stop()
    pbar.grid_remove()
    output = cmd_result.stdout
    outputtextbox.insert(END,output)
    enable_text()

cmdlabel = Label(mainwindow,text='CMD: ',fg='red',font=('Consolas',14))
cmdlabel.grid(row=0,column=0,padx=5,sticky=W)

cmdtextbox = Entry(mainwindow,width=30)
cmdtextbox.grid(row=0,column=1,padx=2,pady=10,sticky=W)

runbtn = Button(mainwindow,text='RUN',fg='blue',command=startcommand)
runbtn.grid(row=0,column=2,padx=10)

outputlabel = Label(mainwindow,text='OUTPUT: ',fg='green',font=('Consolas',10))
outputlabel.grid(row=1,column=0,columnspan=3,padx=10,sticky=W)

outputtextbox = Text(mainwindow,height=10,width=60,font=('Consolas',9))
outputtextbox.grid(row=3,column=0,columnspan=3,padx=10,pady=10,sticky=W)

pbar = Progressbar(mainwindow,orient=HORIZONTAL, length=400,mode="indeterminate")
pbar.grid(row=2,column=0,columnspan=3,padx=10,pady=10,sticky=W)
pbar.grid_remove()

def disable_text():
    cmdtextbox.configure(state='disabled')
def enable_text():
    cmdtextbox.configure(state='normal')
mainwindow.mainloop()



