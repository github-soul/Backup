import os
nowtime = os.popen('sudo aircrack-ng -w /root/RouterSploit/pw.txt /root/Desktop/AP.cap')
result = nowtime.read()
file_handler = open ("/root/Desktop/result_HandShape_Packet.txt", "w")
file_handler.write(result)
file_handler.close()
